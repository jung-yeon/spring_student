package com.nhnacademy.springmvc.domain;

import lombok.Getter;
import lombok.Value;


import javax.validation.constraints.*;

@Value
public class StudentModifyRequest {
    @NotBlank
    String name;

    @Email
    String email;

    @Min(0)
    @Max(100)
    long score;

    @Size(min = 0, max = 100)
    String comment;

}
