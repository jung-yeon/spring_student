package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.Student;
import com.nhnacademy.springmvc.repository.StudentRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class RestStudentController {
    private final StudentRepository studentRepository;

    public RestStudentController(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    @GetMapping("/{studentId}")
    public Student getStudent(@PathVariable("studentId") long Id) {
        return studentRepository.getStudent(Id);
    }

    @PostMapping("")
    public Student postStudent(@RequestBody Student student) {
        Student student1 = Student.create(student.getId(), student.getName(), student.getEmail(), student.getScore(), student.getComment());
        return studentRepository.register(student1.getId(), student1.getName(), student1.getEmail(), student1.getScore(), student1.getComment());
    }

    @PutMapping("/{studentId}")
    public Student putStudent(@RequestBody Student student) {
        Student student1 = studentRepository.getStudent(student.getId());
        student1.setName(student.getName());
        student1.setEmail(student.getEmail());
        student1.setScore(student.getScore());
        student1.setComment(student.getComment());
        studentRepository.modify(student1);
        return studentRepository.getStudent(student1.getId());
    }

}
