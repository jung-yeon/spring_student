package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.Student;

import java.util.List;

public interface StudentRepository {
    boolean exists(long id);

    Student register(long id, String name, String email, long score, String comment);

    Student getStudent(long id);
    void modify(Student student);
    Long getStudentMap();

}
