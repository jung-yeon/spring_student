package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.User;
import com.nhnacademy.springmvc.exception.UserAlreadyExistsException;
import com.nhnacademy.springmvc.exception.UserNotFoundException;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class UserRepositoryImpl implements UserRepository {
    private final Map<String, User> userMap = new HashMap<>();

    @Override
    public boolean exists(String loginid) {
        return userMap.containsKey(loginid);
    }

    @Override
    public boolean matches(String loginid, String password) {
        return Optional.ofNullable(getUser(loginid))
                .map(user -> user.getPassword().equals(password))
                .orElse(false);
    }

    @Override
    public User getUser(String loginid) {
        return exists(loginid) ? userMap.get(loginid) : null;
    }


    @Override
    public User addUser(String loginid, String password) {
        if (exists(loginid)) {
            throw new UserAlreadyExistsException();
        }

        User user = User.create(loginid, password);

        userMap.put(loginid, user);

        return user;
    }

    @Override
    public void modify(User user) {
        User dbUser = getUser(user.getLoginid());
        if (Objects.isNull(dbUser)) {
            throw new UserNotFoundException();
        }
    }

}
