package com.nhnacademy.springmvc.repository;

import com.nhnacademy.springmvc.domain.User;

public interface UserRepository {
    boolean exists(String loginid);
    boolean matches(String loginid, String password);

    User getUser(String loginid);

    User addUser(String loginid, String password);


    void modify(User user);

}
