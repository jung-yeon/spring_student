package com.nhnacademy.springmvc.controller;

import com.nhnacademy.springmvc.domain.Student;
import com.nhnacademy.springmvc.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


class RestStudentControllerTest {
    @Autowired
    WebApplicationContext wac;

    private MockMvc mockMvc;
    StudentRepository studentRepository;

    @BeforeEach
    void setUp() {
        studentRepository = mock(StudentRepository.class);
        mockMvc = MockMvcBuilders.standaloneSetup(new RestStudentController(studentRepository))
                .build();

    }

    @Test
    void getStudent() throws Exception {
        Student student = new Student(1222,"김학생","kim.student@nhnacademy.com",100,"훌륭");
        when(studentRepository.getStudent(1222)).thenReturn(student);

        mockMvc.perform(get("/students/{studentId}",1222)
                .param("id", "1222"))
                .andDo(print())
                .andExpect(status().isOk())
                .andReturn();

    }


    @Test
    void postStudent() throws Exception {
        MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        Student student = new Student(1333,"이학생","Lee.student@nhnacademy.com",40,"부족");
        params.add("id", "1333");
        params.add("name", "이학생");
        params.add("email", "Lee.student@nhnacademy.com");
        params.add("score", "40");
        params.add("comment", "부족");
        mockMvc.perform(post("/students")
                        .params(params)
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isCreated());
    }


    @Test
    void putStudent() throws Exception {

    }
}