package com.nhnacademy.springmvc.domain;

import lombok.Getter;
import lombok.Setter;

public class User {
    @Getter
    private final String loginid;

    @Getter
    private final String password;

    public static User create(String loginid, String password) {
        return new User(loginid, password);
    }

    public User(String loginid, String password) {
        this.loginid = loginid;
        this.password = password;
    }

    private static final String MASK = "*******";

    public static User constructPasswordMaskedUser(User user) {
        User newUser = User.create(user.getLoginid(), MASK);

        return newUser;
    }

}

