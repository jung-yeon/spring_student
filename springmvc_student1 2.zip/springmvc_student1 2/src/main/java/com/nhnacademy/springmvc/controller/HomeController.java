package com.nhnacademy.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {
    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("greeting.language_change", "language_change");
        model.addAttribute("greeting.explain","explain");
        return "thymeleaf/index";
    }

}